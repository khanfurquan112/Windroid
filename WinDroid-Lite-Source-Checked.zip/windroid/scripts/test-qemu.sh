#!/usr/bin/env bash
# ISO ko VM me turant try karein (hardware/WiFi/camera ka test yahan nahi hoga - uske liye real USB boot karein).
# NOTE: Waydroid (Android) VM me aksar nahi chalta; Android ka test real laptop par karein.
set -euo pipefail
ISO="${1:-$(ls -1t windroid-*.iso 2>/dev/null | head -n1)}"
[ -f "${ISO:-}" ] || { echo "Usage: $0 windroid-lite-1.0-amd64.iso"; exit 1; }
command -v qemu-system-x86_64 >/dev/null || { echo "sudo apt install qemu-system-x86"; exit 1; }
ACCEL=(); [ -w /dev/kvm ] && ACCEL=(-enable-kvm -cpu host)
exec qemu-system-x86_64 "${ACCEL[@]}" -m 2048 -smp 2 -vga virtio -display gtk \
  -cdrom "$ISO" -boot d
