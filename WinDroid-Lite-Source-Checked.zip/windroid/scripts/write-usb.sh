#!/usr/bin/env bash
# ISO ko USB pendrive par likhta hai.  Usage: sudo ./scripts/write-usb.sh windroid-lite-1.0-amd64.iso /dev/sdX
# DHYAN: /dev/sdX ka poora data MIT jayega. Sahi device `lsblk` se pehchanein.
set -euo pipefail
ISO="${1:-}"; DEV="${2:-}"
[ -f "$ISO" ] && [ -b "$DEV" ] || { echo "Usage: sudo $0 <iso> </dev/sdX>"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "sudo se chalayein"; exit 1; }
case "$DEV" in *[0-9]) echo "Partition (sdX1) nahi, poora device (sdX) dein."; exit 1;; esac
lsblk -o NAME,SIZE,MODEL,TRAN "$DEV"
read -r -p "Upar wale device par SAB KUCH mit jayega. 'YES' likhein: " a
[ "$a" = "YES" ] || { echo "Cancelled."; exit 1; }
umount "$DEV"* 2>/dev/null || true
dd if="$ISO" of="$DEV" bs=4M status=progress oflag=sync conv=fsync
sync
echo "Ho gaya. USB se boot karne ke liye Dell par F12 dabayein."
