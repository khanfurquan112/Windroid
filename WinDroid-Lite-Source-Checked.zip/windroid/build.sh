#!/usr/bin/env bash
# =====================================================================
#  WinDroid LITE ISO builder  (Debian 13 "trixie" + XFCE + live-build)
#  Usage:   ./build.sh            -> ISO banata hai
#           ./build.sh --clean    -> pehle purana build/cache saaf karta hai
# =====================================================================
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

WD_VERSION="1.0"
ARCH="amd64"
OUT="windroid-lite-${WD_VERSION}-${ARCH}.iso"

say()  { printf '\n\033[1;36m>> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33mWARNING: %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

# --- root chahiye (chroot, mount, debootstrap) -----------------------
if [ "$(id -u)" -ne 0 ]; then
  say "Root chahiye - sudo ke saath dobara chala raha hoon..."
  exec sudo -E bash "$0" "$@"
fi

# --- host check -------------------------------------------------------
# shellcheck disable=SC1091
. /etc/os-release
if [ "${ID:-}" != "debian" ]; then
  warn "Host '${PRETTY_NAME:-unknown}' hai, Debian nahi."
  warn "Ubuntu/Mint ke purane live-build se Debian 13 ISO banana bharosemand nahi hota."
  warn "Behtar: ./build-docker.sh chalayein ya Debian 13 VM me build karein."
  read -r -p "Phir bhi aage badhein? [y/N] " ans
  [[ "$ans" =~ ^[Yy]$ ]] || exit 1
fi

# --- disk space (lite build ko ~12 GB chahiye) ----------------------------
avail_gb=$(df -BG --output=avail . | tail -n1 | tr -dc '0-9')
[ "${avail_gb:-0}" -ge 12 ] || die "Sirf ${avail_gb:-0} GB free hai. Kam se kam 12 GB chahiye."

# --- tools --------------------------------------------------------------
say "Build tools install ho rahe hain (live-build, debootstrap, xorriso ...)"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  live-build debootstrap debian-archive-keyring xorriso squashfs-tools \
  mtools dosfstools syslinux syslinux-common isolinux \
  grub-pc-bin grub-efi-amd64-bin ca-certificates

# --- Windows line-endings (CRLF) hatao + exec bit wapas lagao -----------
# (Windows par unzip/git karne se scripts toot jate hain; ye dono ko theek kar deta hai)
find auto scripts build.sh build-docker.sh config/hooks config/includes.chroot/usr/local/bin \
     -type f -exec sed -i 's/\r$//' {} + 2>/dev/null || true
chmod +x build.sh build-docker.sh auto/* scripts/* 2>/dev/null || true
chmod +x config/hooks/live/*.hook.chroot
chmod +x config/includes.chroot/usr/local/bin/*

# --- clean (optional) ---------------------------------------------------
if [ "${1:-}" = "--clean" ]; then
  say "Purana build saaf ho raha hai"
  lb clean --purge || true
else
  lb clean || true
fi

# --- build --------------------------------------------------------------
say "lb config"
lb config

say "lb build  (pehli baar 45-120 minute lag sakte hain, internet zaroori)"
lb build 2>&1 | tee build.log

# --- result -------------------------------------------------------------
ISO="$(ls -1t ./*.iso 2>/dev/null | head -n1 || true)"
[ -n "$ISO" ] || die "ISO nahi bana. build.log dekhein (neeche ke errors se shuru karein)."

mv -f "$ISO" "$OUT"
sha256sum "$OUT" | tee "$OUT.sha256"
if [ -n "${SUDO_USER:-}" ]; then chown "$SUDO_USER":"$SUDO_USER" "$OUT" "$OUT.sha256" build.log 2>/dev/null || true; fi

say "Ho gaya!  ->  $(pwd)/$OUT"
echo
echo "USB banane ke 2 aasan tareeke (README me detail):"
echo "  1) Ventoy USB par ISO ko seedha copy-paste kar dein, ya"
echo "  2) Rufus / balenaEtcher (Windows) / ./scripts/write-usb.sh (Linux)"
