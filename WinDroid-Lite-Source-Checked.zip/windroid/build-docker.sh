#!/usr/bin/env bash
# Ubuntu/Mint/Fedora host par ISO banane ke liye: Debian 13 container ke andar build chalata hai.
# Zaroori: docker installed ho. (--privileged chahiye kyunki live-build chroot/mount karta hai)
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
command -v docker >/dev/null || { echo "docker nahi mila. Pehle docker install karein."; exit 1; }
TTY=(); [ -t 0 ] && TTY=(-it)
exec docker run --rm "${TTY[@]}" --privileged \
  -v "$PWD":/work -w /work \
  debian:trixie \
  bash -c 'apt-get update && apt-get install -y sudo && bash ./build.sh "$@"' _ "$@"
