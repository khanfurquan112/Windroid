# WinDroid Lite — Source Build Kit

WinDroid Lite is an experimental Debian 13 (Trixie) + XFCE-based desktop image with WinDroid branding, a Windows-style layout, Google Chrome, Wine compatibility tools, NetworkManager, common firmware packages, and an optional Waydroid setup helper.

**Status: Experimental — the ISO has not been built or hardware-tested in this environment.** Treat this as a source kit, not a verified release.

## What is included

- NetworkManager, WPA supplicant, rfkill, common Wi-Fi firmware packages, and libinput utilities.
- A session helper that attempts to enable libinput tap-to-click on supported touchpads.
- GTK3 contrast rules intended to improve visibility of session/logout controls.
- English locale defaults (`en_US.UTF-8`) and generated `en_IN.UTF-8`.
- Visible WinDroid branding (`ID=windroid`, `ID_LIKE=debian`).
- Google Chrome Stable, downloaded from Google's official Debian package endpoint during the build.
- Wine, Wine64, and Winetricks for compatible Windows applications.
- A 1080×1080 animated SVG preview and a custom Plymouth theme source with Windows and Android marks, convergence, a white flash, and a breathing loop.
- A GitHub Actions workflow that builds in a Debian 13 container, checks the ISO checksum, and uploads build logs.

## Important limitations

- The system is Debian-derived. Rebranding does not remove every Debian package, metadata, license, or low-level system reference. A zero-Debian-trace guarantee is not possible with this base.
- Wi-Fi support depends on the actual wireless chipset, kernel driver, and firmware. The package list cannot guarantee every adapter will work.
- Tap-to-click is attempted at session start and depends on the touchpad exposing the expected libinput property.
- Segoe UI is proprietary and is not bundled. Selawik is used as an open-source substitute where available, with Open Sans as a fallback.
- Wine runs only compatible Windows applications. It does not run Windows drivers or guarantee every `.exe` works.
- Chrome requires internet access to `dl.google.com` during the image build.
- Waydroid depends on kernel binder support and sufficient RAM; it is not intended to run as a background service by default.
- Plymouth behavior varies with firmware, graphics drivers, and display mode. The SVG preview is not a guarantee of a particular boot resolution or animation timing.
- The previously reported bugs from an earlier conversation were not included as a separate issue list in the supplied files, so they cannot be individually verified as fixed.

## Build with GitHub Actions

1. Create a GitHub repository.
2. Upload either the contents of the `windroid/` directory to the repository root, or upload the whole `windroid/` directory.
3. Confirm `.github/workflows/build-iso.yml` is present in the repository's `.github/workflows/` directory (at the root if you uploaded the contents).
4. Open **Actions → Build WinDroid Lite ISO → Run workflow**.
5. When the run finishes, download the `windroid-lite-iso` artifact.
6. The artifact can contain the ISO, SHA-256 checksum, `build.log`, and `workflow-container.log`, depending on how far the build progressed.

A push of a tag matching `v*` also triggers a build.

The build needs a working internet connection and substantial temporary disk space. The build script checks for at least 12 GB free, but **20 GB or more is recommended**. Build duration varies with network speed and runner availability; a first build may take a long time.

If the workflow fails, download the log artifacts. Find the first actual error (not just the final failure summary) and include surrounding lines when asking for help.

## Build locally

On Debian 13, with root/sudo access and at least 20 GB free disk:

```bash
./build.sh
```

On Ubuntu or Linux Mint with Docker installed:

```bash
./build-docker.sh
```

To remove the live-build cache before rebuilding:

```bash
./build.sh --clean
```

Expected output:

- `windroid-lite-1.0-amd64.iso`
- `windroid-lite-1.0-amd64.iso.sha256`

This source kit does not include a prebuilt ISO.

## Hardware validation checklist

- [ ] Wi-Fi appears in the network menu and can scan, connect, and reconnect after reboot.
- [ ] Touchpad pointer movement, tap-to-click, physical click, and two-finger scrolling work.
- [ ] English locale is active in the installed system, login screen, and installer.
- [ ] Inspect boot menus, installer pages, and system utilities for remaining Debian references.
- [ ] Chrome launches and updates.
- [ ] Test Wine with a known compatible, non-critical Windows application.
- [ ] Start-menu logout/session controls are visible without hovering.
- [ ] Test the boot animation on real UEFI/BIOS hardware and in a VM.
- [ ] Test suspend/resume, audio, brightness keys, Bluetooth, USB storage, and installation.
- [ ] Verify the generated ISO boots and its SHA-256 checksum passes.

## Main files

- `.github/workflows/build-iso.yml` — GitHub Actions ISO build workflow.
- `config/package-lists/windroid.list.chroot` — base package list.
- `config/hooks/live/0030-theme.hook.chroot` — theme and font setup.
- `config/hooks/live/0040-branding.hook.chroot` — OS and installer branding.
- `config/hooks/live/0060-final-fixes.hook.chroot` — Chrome, locale, and final integration.
- `boot-animation-preview.svg` — square 1080×1080 animated SVG preview.
- `config/includes.chroot/usr/share/plymouth/themes/windroid/` — Plymouth theme assets.
- `config/includes.chroot/usr/local/bin/windroid-touchpad` — tap-to-click helper.

## Licensing

Review applicable licenses for Debian packages, themes, icons, fonts, Wine, Google Chrome, Waydroid, and logos before redistribution. Google Chrome is proprietary and is downloaded from Google's official endpoint at build time.

---

**WinDroid Lite — Experimental Build Kit**

Build first. Test on real hardware. Release only after verification.
