# WinDroid Lite — Source Build Kit

WinDroid Lite is an experimental Debian 13 (Trixie) + XFCE-based desktop image with WinDroid branding, Windows-style layout, Google Chrome, Wine compatibility tools, NetworkManager, hardware firmware, and an optional Waydroid setup helper. It is **not yet a verified release**: build it and test on the target laptop before daily use.

## What this revision changes

- Adds explicit NetworkManager, WPA supplicant, rfkill, common Wi-Fi firmware, and libinput utilities. Wi-Fi still depends on the laptop's actual chipset and firmware support.
- Adds a session helper that enables libinput tap-to-click where the touchpad driver exposes the property. Physical click remains available as fallback.
- Adds GTK3 CSS contrast rules intended to keep Whisker menu session/logout controls visible; verify on the selected theme/plugin version.
- Sets the default session locale to English (`en_US.UTF-8`) while keeping `en_IN.UTF-8` generated.
- Changes visible OS branding to WinDroid and sets `ID=windroid`, `ID_LIKE=debian` for compatibility. This is still Debian-derived; package metadata, `/etc/debian_version`, licenses, and some low-level messages may identify Debian. A Debian base cannot honestly be guaranteed to have zero Debian traces.
- Replaces the Firefox menu favorite with Google Chrome Stable from Google's official Debian package. Chrome download is required during build; if Google download fails, the build stops rather than silently shipping without Chrome.
- Adds Wine/Wine64/Winetricks packages for compatible Windows applications. Not every `.exe` works; drivers, kernel software, and some anti-cheat/modern apps are not supported by Wine.
- Adds a square 1080×1080 animated SVG preview (`boot-animation-preview.svg`) plus a custom Plymouth theme source with Windows and Android marks, convergence, a white flash, and a breathing loop. Plymouth's script API/boot integration is best-effort and **must be visually tested on real UEFI and BIOS hardware**. It is not a guaranteed 1080×1080 video; the theme scales to the boot display.
- Makes the GitHub Actions workflow work whether repository contents are at the root or inside `windroid/`, verifies the checksum, and uploads build logs.

## Build with GitHub Actions

1. Create a GitHub repository. Upload either the contents of this `windroid/` directory to the repository root, or upload the directory itself.
2. Open **Actions → Build WinDroid Lite ISO → Run workflow**. A `v*` tag push also triggers a build.
3. Wait for the job. Download the `windroid-lite-iso` artifact from the completed run. It contains the ISO, SHA-256 checksum, and `build.log` when available.
4. If the build fails, open the failed step and download `build.log`; include the first actual error and about 50 lines before it when requesting help.

The first build needs a working network connection and substantial temporary disk space; allow 1–4 hours depending on GitHub runner/network conditions. The GitHub runner/container must have enough free disk space.

## Build locally

On Debian 13 with root/sudo and at least 20 GB free disk:

```bash
./build.sh
```

On Ubuntu/Mint with Docker installed:

```bash
./build-docker.sh
```

To remove the live-build cache before rebuilding:

```bash
./build.sh --clean
```

Output is `windroid-lite-1.0-amd64.iso` plus its `.sha256` file. This source kit does not include a prebuilt ISO.

## Hardware validation checklist

- Wi-Fi appears in the network menu, can scan, connect, reconnect after reboot, and works after install.
- Touchpad pointer and tap-to-click both work; test two-finger scroll and physical click.
- Confirm the installed locale and check login, installer, boot menu, and system utilities for remaining Debian references.
- Chrome launches and updates. Test Wine with a known compatible, non-critical Windows application.
- Start menu session/logout controls are visible with keyboard focus and pointer hover. If the logout icon remains invisible, capture a screenshot and XFCE theme details; this depends on GTK theme/plugin versions.
- Test boot animation on actual hardware and in a VM. Plymouth behavior differs between UEFI/BIOS and graphics drivers.
- Test suspend/resume, audio, brightness keys, Bluetooth, USB storage, installer, and boot from both UEFI and legacy BIOS if required.

## Known limitations and honest status

- **Not built or hardware-tested in this environment.** A successful ZIP edit is not proof that the ISO builds or hardware works.
- No list of the prior day's separate bugs was present in the supplied files, so those unknown issues cannot be claimed fixed.
- Google Chrome requires network access to `dl.google.com` during image build.
- Wi-Fi depends on the chipset, kernel driver, and firmware availability; this kit cannot promise every laptop adapter will work.
- Wine runs only compatible Windows applications. It does not make Windows drivers or every `.exe` work.
- A Debian-derived OS can be rebranded, but cannot be truthfully guaranteed to contain absolutely no Debian traces.
- Segoe UI itself is proprietary; this kit uses Selawik where available as an open-source substitute, with Open Sans fallback. It does not redistribute Segoe UI.
- Waydroid support depends on kernel binder support and available RAM; it is not enabled as a background service by default.

## Main files

- `.github/workflows/build-iso.yml` — GitHub ISO build workflow.
- `config/package-lists/windroid.list.chroot` — base packages.
- `config/hooks/live/0030-theme.hook.chroot` — theme and font setup.
- `config/hooks/live/0040-branding.hook.chroot` — OS and installer branding.
- `config/hooks/live/0060-final-fixes.hook.chroot` — Chrome, locale, and final integration.
- `boot-animation-preview.svg` — square 1080×1080 animated SVG preview.
- `config/includes.chroot/usr/share/plymouth/themes/windroid/` — boot animation theme source.
- `config/includes.chroot/usr/local/bin/windroid-touchpad` — tap-to-click helper.

## Licensing

Review the licenses of Debian packages, downloaded themes/icons/fonts, Wine, Google Chrome, Waydroid, and any logos before redistribution. Chrome is proprietary and is downloaded from Google's official endpoint at build time.
