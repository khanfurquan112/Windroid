#!/usr/bin/env bash
# Writes the ISO to a USB stick.   Usage: sudo ./scripts/write-usb.sh windroid-lite-1.1-amd64.iso /dev/sdX
# WARNING: everything on /dev/sdX will be erased. Find the right device with `lsblk`.
set -euo pipefail
ISO="${1:-}"; DEV="${2:-}"
[ -f "$ISO" ] && [ -b "$DEV" ] || { echo "Usage: sudo $0 <iso> </dev/sdX>"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "Please run with sudo"; exit 1; }
case "$DEV" in *[0-9]) echo "Give the whole device (sdX), not a partition (sdX1)."; exit 1;; esac
lsblk -o NAME,SIZE,MODEL,TRAN "$DEV"
read -r -p "EVERYTHING on the device above will be erased. Type YES to continue: " a
[ "$a" = "YES" ] || { echo "Cancelled."; exit 1; }
umount "$DEV"* 2>/dev/null || true
dd if="$ISO" of="$DEV" bs=4M status=progress oflag=sync conv=fsync
sync
echo "Done. To boot from the USB stick press F12 on a Dell."
