#!/usr/bin/env bash
# =====================================================================
#  WinDroid Lite ISO builder  (Debian 13 "trixie" + XFCE + live-build)
#  Usage:   ./build.sh            -> builds the ISO
#           ./build.sh --clean    -> wipes the old build/cache first
# =====================================================================
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

WD_VERSION="1.1"
ARCH="amd64"
OUT="windroid-lite-${WD_VERSION}-${ARCH}.iso"

say()  { printf '\n\033[1;36m>> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33mWARNING: %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

# --- root is required (chroot, mount, debootstrap) ---------------------
if [ "$(id -u)" -ne 0 ]; then
  say "Root is required - re-running with sudo..."
  exec sudo -E bash "$0" "$@"
fi

# --- host check ----------------------------------------------------------
# shellcheck disable=SC1091
. /etc/os-release
if [ "${ID:-}" != "debian" ]; then
  warn "This host is '${PRETTY_NAME:-unknown}', not Debian."
  warn "An old live-build on Ubuntu/Mint may not build a Debian 13 ISO reliably."
  warn "Better: run ./build-docker.sh (Debian 13 container) or use a Debian 13 VM."
  read -r -p "Continue anyway? [y/N] " ans
  [[ "$ans" =~ ^[Yy]$ ]] || exit 1
fi

# --- disk space (the build needs about 12 GB) -----------------------------
avail_gb=$(df -BG --output=avail . | tail -n1 | tr -dc '0-9')
[ "${avail_gb:-0}" -ge 12 ] || die "Only ${avail_gb:-0} GB free. At least 12 GB are required."

# --- tools -------------------------------------------------------------------
say "Installing build tools (live-build, debootstrap, xorriso ...)"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  live-build debootstrap debian-archive-keyring xorriso squashfs-tools \
  mtools dosfstools syslinux syslinux-common isolinux \
  grub-pc-bin grub-efi-amd64-bin ca-certificates python3 python3-pil

# --- fix Windows line endings (CRLF) and restore exec bits ---------------------
# (unzipping / cloning on Windows can break scripts; this repairs both problems)
find auto scripts build.sh build-docker.sh config/hooks config/includes.chroot/usr/local/bin \
     -type f -exec sed -i 's/\r$//' {} + 2>/dev/null || true
chmod +x build.sh build-docker.sh auto/* scripts/* 2>/dev/null || true
chmod +x config/hooks/live/*.hook.chroot config/hooks/live/*.hook.binary
chmod +x config/includes.chroot/usr/local/bin/*

# --- clean (optional) -------------------------------------------------------------
if [ "${1:-}" = "--clean" ]; then
  say "Cleaning the previous build"
  lb clean --purge || true
else
  lb clean || true
fi

# --- build ----------------------------------------------------------------------------
say "lb config"
lb config

say "lb build  (the first build takes 30-90 minutes and needs internet)"
lb build 2>&1 | tee build.log

# --- result -----------------------------------------------------------------------------
ISO="$(ls -1t ./*.iso 2>/dev/null | head -n1 || true)"
[ -n "$ISO" ] || die "No ISO was produced. Check build.log (start from the first error)."

mv -f "$ISO" "$OUT"
sha256sum "$OUT" | tee "$OUT.sha256"
if [ -n "${SUDO_USER:-}" ]; then chown "$SUDO_USER":"$SUDO_USER" "$OUT" "$OUT.sha256" build.log 2>/dev/null || true; fi

say "Done!  ->  $(pwd)/$OUT"
echo
echo "Two easy ways to make the USB stick (details in README.md):"
echo "  1) Ventoy: install it once, then just copy the ISO onto the stick, or"
echo "  2) Rufus (DD Image mode) / balenaEtcher / ./scripts/write-usb.sh on Linux"
