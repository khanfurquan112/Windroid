#!/usr/bin/env bash
# Build the ISO inside a Debian 13 container (for Ubuntu / Mint / Fedora hosts).
# Requires docker. (--privileged is needed because live-build uses chroot and mounts.)
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
command -v docker >/dev/null || { echo "docker not found. Please install docker first."; exit 1; }
TTY=(); [ -t 0 ] && TTY=(-it)
exec docker run --rm "${TTY[@]}" --privileged \
  -v "$PWD":/work -w /work \
  debian:trixie \
  bash -c 'apt-get update && apt-get install -y sudo && bash ./build.sh "$@"' _ "$@"
