#!/usr/bin/env python3
"""Renders a 1080x1080 preview of the WinDroid boot animation.
Uses the SAME timeline/maths as the Plymouth script (windroid.script)."""
import math, subprocess, sys, os
import numpy as np
from PIL import Image

D = sys.argv[1] if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else "windroid-boot-animation-1080x1080.mp4"
S = 1080; FPS = 30; DUR = 9.0
# timeline (seconds) - keep identical to windroid.script
T_START, T_SLIDE = 0.4, 1.2
T_FLASH = T_START + T_SLIDE          # 1.6  meeting moment -> flash
T_PEAK  = T_FLASH + 0.08             # 1.68 white peak, logos swap to merged
T_FEND  = T_PEAK + 0.55              # flash fade out
T_DIM   = T_PEAK + 0.72              # merged settles to dim
DIM, PERIOD = 0.35, 2.4
OFFSET = S/2 + 0.30*S

def load(n): return np.asarray(Image.open(os.path.join(D, n)).convert("RGBA")).astype(np.float32)/255.0
win, droid, merged = load("win.png"), load("droid.png"), load("merged.png")

def shift(img, dx):
    out = np.zeros_like(img); dx = int(round(dx))
    if dx >= 0: out[:, dx:] = img[:, :S-dx] if dx < S else 0
    else:       out[:, :S+dx] = img[:, -dx:] if -dx < S else 0
    return out

def over(dst, src, opacity=1.0):
    a = src[..., 3:4] * opacity
    dst[..., :3] = src[..., :3]*a + dst[..., :3]*(1-a)

def merged_opacity(t):
    if t < T_PEAK: return 0.0
    if t < T_DIM:
        q = (t - T_PEAK)/(T_DIM - T_PEAK); return 1 - (1-DIM)*(q*q*(3-2*q))
    return DIM + (1-DIM)*(0.5 - 0.5*math.cos(2*math.pi*(t - T_DIM)/PERIOD))

def flash_level(t):
    if t < T_FLASH: return 0.0
    if t < T_PEAK:  return (t - T_FLASH)/(T_PEAK - T_FLASH)
    if t < T_FEND:  return 1 - (t - T_PEAK)/(T_FEND - T_PEAK)
    return 0.0

def frame(t):
    img = np.zeros((S, S, 4), np.float32); img[..., 3] = 1
    if t < T_PEAK:
        p = min(max((t - T_START)/T_SLIDE, 0), 1); e = 1 - (1-p)**3
        over(img, shift(win,   -(1-e)*OFFSET))
        over(img, shift(droid, +(1-e)*OFFSET))
    else:
        over(img, merged, merged_opacity(t))
    f = flash_level(t)
    if f > 0: img[..., :3] = img[..., :3]*(1-f) + f
    return (img[..., :3]*255).astype(np.uint8)

if __name__ == "__main__":
    cmd = ["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgb24","-s",f"{S}x{S}","-r",str(FPS),
           "-i","-","-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-movflags","+faststart",OUT]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(int(DUR*FPS)):
        p.stdin.write(frame(i/FPS).tobytes())
    p.stdin.close(); p.wait(); print("wrote", OUT)
